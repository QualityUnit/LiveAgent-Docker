<?php

namespace Resque\Pool;

use Resque\Exception;

class PoolStateException extends Exception {
}