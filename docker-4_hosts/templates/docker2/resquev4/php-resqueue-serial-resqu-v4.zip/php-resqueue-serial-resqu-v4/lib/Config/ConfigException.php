<?php

namespace Resque\Config;

use Resque\Exception;

class ConfigException extends Exception {

}