<?php


namespace Resque\Job;


use Resque\Exception;

class FailException extends Exception {
}